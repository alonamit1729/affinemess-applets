# Certificates for discarded patterns

The proof in `../two-shapes.ipynb` needs to know that at most 228 distance patterns occur for ten points
in the plane with at most six distances. The number first appeared in Table 9 of Szöllősi and Östergård;
it comes out of a generation, level by level from four to ten points, in which candidates are *discarded*
when they are shown not to occur.

This folder derives the 228 with a certificate for every discarded candidate: a polynomial identity that
can be checked by multiplying out, and nothing else. Section 3 of the notebook explains the method and
rests on these files.

## Result (18 November 2026)

| points | candidates | certificates | kept | degree of the product: 3 / 4 / 5 |
|---:|---:|---:|---:|---:|
| 4 | 25 | 1 | 24 | 1 / 0 / 0 |
| 5 | 1,193 | 271 | 922 | 237 / 34 / 0 |
| 6 | 537,230 | 517,001 | 20,229 | 380,254 / 135,749 / 998 |
| 7 | 14,732 | 10,065 | 4,667 | 10,065 / 0 / 0 |
| 8 | 1,565 | 0 | 1,565 | |
| 9 | 635 | 0 | 635 | |
| 10 | 228 | 0 | 228 | |

A *candidate* on n points is a pattern with at most six colours all of whose (n-1)-point sub-patterns are
kept at the level below. Every number in the table equals the corresponding number in Table 9 of Szöllősi
and Östergård, and the 228 patterns at ten points are the 228 of `../data/L10.json`.

All 527,338 certificates pass `check.py`, both when they were made and again as the final files. From eight
points on nothing needs to be discarded, and the search finds no certificate (with a product of degree up
to 5) for any of the 2,428 candidates there.

## What a certificate is

Take a pattern on n points with colours 0..k-1, and suppose points of the plane have it, with squared
distances x_0, ..., x_{k-1} (positive and pairwise different). For a base point b put

    G_ij = x_c(b,i) + x_c(b,j) - x_c(i,j),        G_ii = 2 x_c(b,i)        (i, j different from b)

where c(i,j) is the colour of the pair. This is twice the Gram matrix of the vectors p_i - p_b, which lie
in a plane, so every 3x3 minor of G is zero. The minors are cubic polynomials in the x.

A certificate is a polynomial identity

    scale * (a product of factors x_c and x_a - x_b)  =  sum of (polynomial) * (minor)

with a non-zero integer `scale`. At the point x the right side is zero and the left side is not, so no
such points exist. Example, the first five-point certificate:

    18 x_0^3  =  13 M_0(123;123) - 3 M_1(234;234) - 22 M_0(123;124)

where M_b(rows;columns) is the minor of G for the base point b. The "degree of the product" in the table
is the number of factors on the left; for degree 3 the multipliers are plain integers, as here.

`check.py` checks such identities. Its function `check` is about fifty lines of pure Python, uses
integers only, and recomputes the minors from the pattern itself; the notebook shows it in full. It is the only code here that has to be trusted for the
certificates.

## Checking

The five-point certificates are in this folder. The six- and seven-point ones are too large for the
repository (1.2 GB as text) and are attached to the release `certificates-v1`:

    https://github.com/alonamit1729/affinemess-applets/releases/download/certificates-v1/level6.jsonl.gz
    https://github.com/alonamit1729/affinemess-applets/releases/download/certificates-v1/level7.jsonl.gz

    python3 check.py --jobs 4 level5.jsonl level6.jsonl.gz level7.jsonl.gz

This takes about 45 core-minutes. `SHA256SUMS` lists the checksums of the three files.

## The candidates, generated twice

That the candidates at each level are *all* the patterns whose sub-patterns are kept is combinatorics:
an exhaustive generation. It was done by two programs that share no code.

* `tools/fixed-distances/g7fin/gen/gen.py`, from earlier work: canonical forms by nauty, lookup tables
  for small sub-patterns. Its candidate lists are the ones the certificates were computed for.
* `generate.py` in this folder: pure Python, canonical forms by `fewdist.canonical` (the notebook's own),
  a different organisation of the search. Its docstring says why no candidate can be missed.

      python3 generate.py 6 --jobs 2 --certificates level6.jsonl.gz

  For n = 5, 6, 7 it finds 1,193, 537,230 and 14,732 candidates, and the ones that are not kept are
  exactly the patterns with a certificate: 271, 517,001 and 10,065. For n = 8, 9, 10 it finds 1,565, 635
  and 228 candidates, exactly the lists `L8.json`, `L9.json`, `L10.json`. All six levels take about
  13 minutes on two cores.

At six points, where 98 % of the discards are, a third enumeration without any pruning
(`fewdist.add_a_point`, which tries every colouring of the five new pairs) gives the same 537,230.

## What this does and does not establish

* Each certificate proves that its pattern is not the pattern of any planar point set. That part needs
  only `check.py`.
* The lists of candidates are complete, as far as two independent programs and the published counts can
  show; `generate.py` also checks that every candidate is kept or has a certificate.
* Together: every planar set of ten points with at most six distances has one of the 228 patterns of
  `L10.json`.
* This is Proposition A of the notebook, whose proof (section 3.6) uses these files and nothing from the
  literature.

How the certificates were found does not matter for their validity. For the record: `fast.py` computes
the minors, works modulo a prime with the degree-d part of the ideal they generate, tests *all* products
of d forbidden factors against it (d = 3, 4, 5), and then solves for the multipliers exactly. On the
kept side, `kept_check.py` was run on a sample at six points (see the table of files).

## Files

| file | what it is |
|---|---|
| `check.py` | the checker |
| `level5.jsonl` | 272 certificates: the one-coloured four-point pattern and the 271 discarded five-point candidates |
| `L5.json`, `L6.json`, `L7.json` | the patterns kept at five, six and seven points (922, 20,229, 4,667) |
| `L8.json`, `L9.json`, `L10.json` | the candidates at eight, nine and ten points (1,565, 635, 228), all kept |
| `summary.json` | the numbers of the table above |
| `level6_sample.jsonl.gz`, `level7_sample.jsonl.gz` | 400 and 200 certificates drawn at random from the two large files; the notebook checks them on every run |
| `SHA256SUMS` | checksums of `level5.jsonl`, `level6.jsonl.gz`, `level7.jsonl.gz` |
| `generate.py` | the second generation of the candidates (pure Python), with the check that each is kept or certified |
| `fast.py`, `find.py` | the search (numpy, python-flint); `find.py` is the first version, used by the pilot |
| `run_level5.py` | five points, start to finish |
| `run_level.py`, `finish_level.py` | a whole level in resumable chunks, and collecting it |
| `pilot6_sample.json`, `pilot6.jsonl.gz`, `pilot6_kept.json`, `run_pilot6.py` | the pilot: 1,060 random six-point candidates |
| `kept_check.py` | a check on the kept side, not part of any proof: for the 50 kept candidates of the pilot there is, modulo the prime, a solution of the equations at which no forbidden factor vanishes |

The download of the notebook (`16-7-proof-notebook.zip`) contains the files of this table down to
`generate.py`; the search programs and the pilot are in the repository only.

A certificate is one JSON object per line: `n`, `pattern`, `scale`, `product` (factors `[c]` for x_c or
`[a, b]` for x_a - x_b, each with its exponent) and `terms` (base point, rows, columns, and the multiplier
as a list of `[coefficient, exponents]`).

## Running it again

    python3 run_level5.py                                                                     # 8 minutes
    python3 run_level.py 6 raw6.json run6 && python3 finish_level.py 6 run6 raw6.json out     # 4.5 core-hours
    python3 run_level.py 7 raw7.json run7 && python3 finish_level.py 7 run7 raw7.json out     # 20 core-minutes

`raw6.json` and `raw7.json` are the candidate lists written by `gen.py --gen-only` from `L5.json` and
`L6.json`. The runs are deterministic.

    python3 generate.py N --jobs 2 [--certificates levelN.jsonl.gz]      # N = 5..10, the second generation
